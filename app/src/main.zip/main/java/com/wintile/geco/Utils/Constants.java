package com.wintile.geco.Utils;

public class Constants {
    //TODO Specify urls
    public static final String queryUrl = "";
    public static final String FETCH_PRODUCT_DATA = "";
    public static final String CONTACT_NUMBER = "1234567";
}
