package com.wintile.geco;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
/*

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
*/
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.wintile.geco.Utils.Constants;
import com.wintile.geco.Utils.FlipHorizontalTransformer;
import com.wintile.geco.Utils.ItemClickListener;
import com.wintile.geco.Utils.JSONParser;
import com.wintile.geco.Utils.ViewPagerScroller;
import com.wintile.geco.adapter.RecyclerViewDataAdapter;
import com.wintile.geco.adapter.SliderAdapter;
import com.wintile.geco.store.DBHelper;
import com.wintile.geco.models.ProductModel;
import com.wintile.geco.models.SectionDataModel;
import com.wintile.geco.models.SingleItemModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import static com.wintile.geco.Utils.Constants.FETCH_PRODUCT_DATA;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener, ItemClickListener, OnMapReadyCallback {

    public static final String EXTRA_ANIMAL_ITEM = "animal_image_url";
    public static final String EXTRA_ANIMAL_IMAGE_TRANSITION_NAME = "animal_image_transition_name";
    ImageView ivOne;

    private static final String LOG_TAG = "MainActivity";

    private ArrayList<SectionDataModel> allSampleData;
    ViewPager viewPager;
    SliderAdapter sliderAdapter;

    int images[] = {
            R.drawable.img_1,
            R.drawable.img_2,
            R.drawable.img_3
    };

    Timer timer;
    final long DELAY_MS = 10000;
    final long PERIOD_MS = 5000;

    TextView tvContact, tvEmail;
    EditText etSubject, etMessage, etEmail, etPhone;
    Button btnSend;

    private GoogleMap mMap;
    private ProgressDialog pDialog;


    //Permission
    final static String[] PERMISSIONS = {android.Manifest.permission.CALL_PHONE};
    final static int PERMISSION_ALL = 1;

    JSONParser jsonParser = new JSONParser();

    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DBHelper(getApplicationContext());
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        allSampleData = new ArrayList<>();

        createDummyData();
        if (Build.VERSION.SDK_INT >= 23 && !isPermissionGranted()) {
            requestPermissions(PERMISSIONS, PERMISSION_ALL);
        }
        viewPager = (ViewPager) findViewById(R.id.view_pager);
        sliderAdapter = new SliderAdapter(this, images);
        viewPager.setAdapter(sliderAdapter);
        viewPager.setPageTransformer(true, new FlipHorizontalTransformer());

        ViewPagerScroller scroller = new ViewPagerScroller(viewPager.getContext());
        scroller.setViewPagerScrollSpeed(viewPager, 3000);

        TimerTask timerTask = new TimerTask() {
            @Override
            public void run() {
                viewPager.post(new Runnable() {
                    @Override
                    public void run() {
                        int currentPage = (viewPager.getCurrentItem() + 1) % images.length;
                        viewPager.setCurrentItem(currentPage, true);
                    }
                });
            }
        };

        timer = new Timer();
        timer.schedule(timerTask, DELAY_MS, PERIOD_MS);
        ivOne = (ImageView) findViewById(R.id.ivOne);
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.my_recycler_view);
        recyclerView.setHasFixedSize(true);
        RecyclerViewDataAdapter adapter = new RecyclerViewDataAdapter(allSampleData, this, this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        recyclerView.setAdapter(adapter);


        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);



        tvContact = findViewById(R.id.tvContact);
        tvEmail = findViewById(R.id.tvEmail);
        etMessage = findViewById(R.id.etMessage);
        etSubject = findViewById(R.id.etSubject);
        etEmail = findViewById(R.id.etEmail);
        etPhone = findViewById(R.id.etPhone);
        btnSend = findViewById(R.id.btnSend);

        tvContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String uri = "tel:" + Constants.CONTACT_NUMBER;
                Intent intent = new Intent(Intent.ACTION_CALL);
                intent.setData(Uri.parse(uri));
                if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    if (Build.VERSION.SDK_INT >= 23 && !isPermissionGranted()) {
                        requestPermissions(PERMISSIONS, PERMISSION_ALL);
                    }
                    return;
                }
                startActivity(intent);
            }
        });
       /* tvEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent emailIntent = new Intent(Intent.ACTION_SEND, Uri.parse("mailto:"+ tvEmail.getText().toString().trim()));
                emailIntent.setType("text/plain");
                startActivity(emailIntent);
            }
        });*/

       btnSend.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               querySend(view, etSubject.getText().toString(), etMessage.getText().toString(), etPhone.getText().toString().trim(), etEmail.getText().toString().trim());
           }
       });
    }


     private boolean isPermissionGranted() {
            return Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && (checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED);
    }

    private final String android_image_urls[] = {
            "http://api.learn2crack.com/android/images/donut.png",
            "http://api.learn2crack.com/android/images/eclair.png",
            "http://api.learn2crack.com/android/images/froyo.png",
            "http://api.learn2crack.com/android/images/ginger.png",
            "http://api.learn2crack.com/android/images/honey.png",
            "http://api.learn2crack.com/android/images/icecream.png",
            "http://api.learn2crack.com/android/images/jellybean.png",
            "http://api.learn2crack.com/android/images/kitkat.png",
            "http://api.learn2crack.com/android/images/lollipop.png",
            "http://api.learn2crack.com/android/images/marshmallow.png",
            "http://api.learn2crack.com/android/images/donut.png",
            "http://api.learn2crack.com/android/images/eclair.png",
            "http://api.learn2crack.com/android/images/froyo.png",
            "http://api.learn2crack.com/android/images/ginger.png",
            "http://api.learn2crack.com/android/images/honey.png",
            "http://api.learn2crack.com/android/images/icecream.png",
            "http://api.learn2crack.com/android/images/jellybean.png",
            "http://api.learn2crack.com/android/images/kitkat.png",
            "http://api.learn2crack.com/android/images/lollipop.png",
            "http://api.learn2crack.com/android/images/marshmallow.png",
            "http://api.learn2crack.com/android/images/donut.png",
            "http://api.learn2crack.com/android/images/eclair.png",
            "http://api.learn2crack.com/android/images/froyo.png",
            "http://api.learn2crack.com/android/images/ginger.png",
            "http://api.learn2crack.com/android/images/honey.png",
            "http://api.learn2crack.com/android/images/icecream.png",
            "http://api.learn2crack.com/android/images/jellybean.png",
            "http://api.learn2crack.com/android/images/kitkat.png",
            "http://api.learn2crack.com/android/images/lollipop.png",
            "http://api.learn2crack.com/android/images/marshmallow.png"
    };

    private final String android_version_names[] = {
            "Donut",
            "Eclair",
            "Froyo",
            "Gingerbread",
            "Honeycomb",
            "Ice Cream Sandwich",
            "Jelly Bean",
            "KitKat",
            "Lollipop",
            "Marshmallow",
            "Donut",
            "Eclair",
            "Froyo",
            "Gingerbread",
            "Honeycomb",
            "Ice Cream Sandwich",
            "Jelly Bean",
            "KitKat",
            "Lollipop",
            "Marshmallow",
            "Donut",
            "Eclair",
            "Froyo",
            "Gingerbread",
            "Honeycomb",
            "Ice Cream Sandwich",
            "Jelly Bean",
            "KitKat",
            "Lollipop",
            "Marshmallow"
    };

    private void createDummyData() {
        /*for (int i = 0; i < 20; i++) {
            SectionDataModel dm = new SectionDataModel();
            dm.setHeaderTitle("Section " + i);
            ArrayList<SingleItemModel> singleItemModels = new ArrayList<>();
            for (int j = 0; j < 20; j++) {
                singleItemModels.add(new SingleItemModel(android_version_names[j], android_image_urls[j]));
            }
            dm.setAllItemInSection(singleItemModels);
            allSampleData.add(dm);
        }*/

        List<String> categories = dbHelper.getCategory();
        //dbHelper.getAllProducts();
        for (String cat : categories){
            Log.e("cat", cat);
            SectionDataModel dm = new SectionDataModel();
            ArrayList<SingleItemModel> singleItemModels = new ArrayList<>();
            dm.setHeaderTitle(cat);
            ArrayList<ProductModel> productModels = (ArrayList<ProductModel>) dbHelper.getProducts(cat);
            for (ProductModel productModel: productModels){
                Log.e("Product", productModel.getProductName());
                singleItemModels.add(new SingleItemModel(productModel.getProductName(), productModel.getImgUrl(), productModel.getCategory(), productModel.getProdutID(), productModel.getShareUrl(), productModel.getDesc(), productModel.getSpecs()));
            }
            dm.setAllItemInSection(singleItemModels);
            allSampleData.add(dm);
        }
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
        } else if (id == R.id.nav_gallery) {
            startActivity(new Intent(this, GalleryActivity.class));
        } else if (id == R.id.nav_products) {
            startActivity(new Intent(this, ProductActivity.class));
        } else if (id == R.id.nav_deals) {
            startActivity(new Intent(this, DealsActivity.class));
        } else if (id == R.id.nav_saved) {
            startActivity(new Intent(this, SavedActivity.class));
        } else if (id == R.id.nav_share) {
            //TODO write a brief description about app
            Intent sendIntent = new Intent();
            sendIntent.setAction(Intent.ACTION_SEND);
            sendIntent.putExtra(Intent.EXTRA_TEXT,
                    "Hey check out my app at: https://play.google.com/store/apps/details?id=com.google.android.apps.plus");
            sendIntent.setType("text/plain");
            startActivity(sendIntent);

        } else if (id == R.id.nav_contact) {
            startActivity(new Intent(this, AboutActivity.class));
        } else if (id == R.id.nav_powered) {
            startActivity(new Intent(this, PoweredByActivity.class));
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    //TODO change Deals nav icon and aboutus logo
    @Override
    public void onAnimalItemClick(int pos, SingleItemModel animalItem, ImageView sharedImageView) {
        Intent intent = new Intent(this, itemDetailsActivity.class);
        intent.putExtra(EXTRA_ANIMAL_ITEM, animalItem);

        intent.putExtra(EXTRA_ANIMAL_IMAGE_TRANSITION_NAME, ViewCompat.getTransitionName(sharedImageView));

        Log.e("yup", animalItem.getName() + "\n" + animalItem.getProdutID() + "\n" + animalItem.getCategory() + "\n" + animalItem.getDesc()+ "\n" +animalItem.getSpecs()+ "\n" + animalItem.getShareUrl());

        Bundle bundle = new Bundle();
        bundle.putString("URL", animalItem.getUrl());
        bundle.putInt("ProductID", animalItem.getProdutID());
        bundle.putString("ProductName", animalItem.getName());
        bundle.putString("ShareURL", animalItem.getShareUrl());
        bundle.putString("Desc", animalItem.getDesc());
        bundle.putString("Specs", animalItem.getSpecs());
        bundle.putString("Category", animalItem.getCategory());
        bundle.putBoolean("like", false);
        intent.putExtras(bundle);
        ActivityOptionsCompat options = ActivityOptionsCompat.makeSceneTransitionAnimation(
                this,
                sharedImageView,
                ViewCompat.getTransitionName(sharedImageView));
        Log.e("oops", String.valueOf(pos));
        startActivity(intent, options.toBundle());
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */

   @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in geco and move the camera
        LatLng geco = new LatLng(10.998791, 77.023263);
        mMap.addMarker(new MarkerOptions().position(geco).title("Geco Crushers"));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(10.998791, 77.023263), 12.0f));
        mMap.getUiSettings().setMapToolbarEnabled(true);
    }

    //querySend
    public void querySend(final View view, final String subject,final String message, final String phone, final String email) {


        RequestQueue queue = Volley.newRequestQueue(MainActivity.this);

        // Request a string response from the provided URL.
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.queryUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Snackbar.make(view, "Successful", Snackbar.LENGTH_LONG).show();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Snackbar.make(view, "Unsuccessful", Snackbar.LENGTH_INDEFINITE).setAction("Retry", new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        querySend( view,  subject, message, phone, email);
                    }
                }).show();
            }
        }) {

            //adding parameters to the request
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("subject", subject);
                params.put("message", message);
                params.put("phone", phone);
                params.put("email", email);

                return params;
            }
        };
        // Add the request to the RequestQueue.
        queue.add(stringRequest);


    }


    /**
     * AsyncTask to getProduct
     */
    private class LoadProductData extends AsyncTask<URL, Void, ProductModel> {

        /**
         * Before starting background thread Show Progress Dialog
         */
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(MainActivity.this);
            pDialog.setMessage("Getting things Ready");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(false);
            pDialog.show();
        }

        @Override
        protected void onPostExecute(ProductModel constable) {
            super.onPostExecute(constable);
            pDialog.dismiss();
        }

        @Override
        protected ProductModel doInBackground(URL... urls) {

            URL urlOffender = jsonParser.createUrl(FETCH_PRODUCT_DATA);

            String jsonResponseOffender = "";
            Log.e("next", "donecreatingurl");
            try{
                jsonResponseOffender = jsonParser.makeHttpRequest(urlOffender);
            }catch (IOException e){
                Log.e(LOG_TAG, "let me see", e);
            }

            extractFeatureFromJsonOffender(jsonResponseOffender);
            return null;
        }

        //method to parse offender json.
        private void extractFeatureFromJsonOffender(String offenderJson) {
            try {
                JSONObject baseJsonResponse = new JSONObject(offenderJson);
                JSONArray productArray = baseJsonResponse.getJSONArray("products");

                for(int i = 0; i< productArray.length(); i++){
                    JSONObject firstlist = productArray.getJSONObject(i);
                    int ProductID  = Integer.parseInt(firstlist.getString("ProductID"));
                    String ProductName = firstlist.getString("ProductName");
                    String Category = firstlist.getString("Category");
                    String ImgID = firstlist.getString("ImgID");
                    String SpecsUrl = firstlist.getString("SpecsUrl");
                    String WebUrl = firstlist.getString("WebUrl");
                    String Description = firstlist.getString("Description");
                    dbHelper.createTableProductList(new ProductModel(  ProductName, Category, ImgID, ProductID, WebUrl, Description, SpecsUrl));
                    //Log.e("offender", name + "\t" + id + "\t" + type + "\t" + category + "\t" + beatnumber+ "\n");
                }
            } catch (JSONException e) {
                Log.e(LOG_TAG, "Problem parsing the Offender JSON results", e);
            }
        }
    }
}
