package com.wintile.geco;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class PoweredByActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_powered_by);
    }
}
